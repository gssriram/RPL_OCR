from django import forms
from django.forms import ModelForm
from .models import ImageUpload

class image_upload(ModelForm):
    class Meta:
        model=ImageUpload
        fields="__all__"
        labels={'cheque_image':'',}
