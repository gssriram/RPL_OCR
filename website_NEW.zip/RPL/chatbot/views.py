from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import ImageUpload
from .forms import image_upload
from django.http import HttpResponseRedirect
import requests
import json
import numpy
import cv2
import re
import os

# Create your views here.

def home(request):
    return(render(request, 'home.html', {}))

def cts(request):
    submitted = False
    if request.method == "POST":
        form=image_upload(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return(HttpResponseRedirect('/cts-results') )
    else:
        form = image_upload
        if 'submitted' in request.GET:
            submitted = True

    return(render(request, 'cts.html', {'form':form}))

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request,user)
            messages.success(request, 'Log In Successfull !!!')
            return redirect('cts')
        else:
            messages.success(request, 'Either Username or Password is incorrect. Please try again...')
            return redirect('cts')
    else:
        return(render(request, 'user_login.html', {}))

def user_logout(request):
    logout(request)
    messages.success(request, "You've been logged out successfully !!!")
    return redirect('home')

def ocr_space_file(filename, overlay=False, api_key='K81673339088957', language='eng'):
    payload = {'isOverlayRequired': overlay,
               'apikey': api_key,
               'language': language,
               'ocrengine': 2
               }
    with open(filename, 'rb') as f:
        r = requests.post('https://api.ocr.space/parse/image',
                          files={filename: f},
                          data=payload,
                          )
    return r.content.decode()

def splitter(text):
    temp = json.loads(text)
    temp = dict(temp['ParsedResults'][0]['TextOverlay'])['Lines']
    a_temp = ''
    for i in range(len(temp)):
        a_temp += '-'+ dict(temp[i])['LineText']
    return a_temp

def img_read(img_url):
    img = cv2.imread('/home/Invincibles/RPL'+img_url)
    img = cv2.resize(img, (2365,1100))
    rows, cols, _ = img.shape
    #print("Rows", rows)
    #print("Cols", cols)

    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #img = np.clip(img + 30, 0, 255)
    img = cv2.GaussianBlur(img, (5, 5), 0)
    #img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 199, 5)
    ###   Account Number   ###
    cut_image = img[545:655, 280:1300]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('ano.png',cut_image)
    ###   Date   ###
    cut_image = img[65:175, 1790:2360]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('date.png',cut_image)
    ###   Payee   ###
    cut_image = img[190:340, 175:1880]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('payee.png',cut_image)
    ###   Amount (words 1)   ###
    cut_image = img[300:422, 350:2355]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('amount_words(1).png',cut_image)
    ###   Amount (words 2)   ###
    cut_image = img[400:500, 150:1545]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('amount_words(2).png',cut_image)
    ###   Amount   ###
    cut_image = img[400:558, 1680:2325]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('amount.png',cut_image)
    ###   Payer   ###
    cut_image = img[600:915, 1680:2325]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('payer.png',cut_image)
    ###   Ch-details   ###
    cut_image = img[900:1100, 100:2350]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('Ch_details.png',cut_image)
    ###   Bank details   ###
    cut_image = img[10:230, 100:1600]
    #cv2.imshow('Cut', cut_image)
    #cv2.waitKey(0)
    cv2.imwrite('bank details.png',cut_image)
    text = test_file = ocr_space_file(filename='amount.png')
    amount = splitter(text)
    amount = amount.split('.')[0]
    amount = ''.join(re.findall(r'\d+', amount))
    #print(f'Amount: {amount}')
    text = test_file = ocr_space_file(filename='amount_words(1).png')
    amount_words_1 = splitter(text)
    #print(f'Amount Words 1: {amount_words_1}')
    text = test_file = ocr_space_file(filename='amount_words(2).png')
    amount_words_2 = splitter(text)
    #print(f'Amount Words 2: {amount_words_2}')
    awo = ''.join((amount_words_1+amount_words_2).split('-'))
    #print(f'Amount Words: {awo}')
    text = test_file = ocr_space_file(filename='ano.png')
    ano = splitter(text)
    ano = ano.split('-')[1]
    #print(f'A/C #: {ano}')
    text = test_file = ocr_space_file(filename='bank details.png')
    bank_details = splitter(text)
    bank = bank_details.split('-')[1]
    #print(f'Bank: {bank}')
    bank_address = ' '.join(bank_details.split('IFS')[0].split('-')[:-1])
    #print(f'Bank Address: {bank_address}')
    for i in bank_details.split('IFS')[-1].split('-'):
        i = i.split(' ')
        for j in i:
            if len(j) == 11:
                ifsc = j
    #print(f'IFSC: {ifsc}')
    text = test_file = ocr_space_file(filename='Ch_details.png')
    ch_details = splitter(text)
    #print(f'Cheque Details: {ch_details}')
    text = test_file = ocr_space_file(filename='date.png')
    date = splitter(text)
    date = ''.join(re.findall(r'\d+', date))
    #print(f'Date: {date}')
    text = test_file = ocr_space_file(filename='payee.png')
    payee = splitter(text)
    payee = payee.split('-')[1]
    #print(f'Payee: {payee}')
    text = test_file = ocr_space_file(filename='payer.png')
    payer = splitter(text)
    payer_temp = payer.split('-')[-2]
    #if (payer_temp == payer.split('-')[1]):
    #    payer_temp = 'N/A'
    #print(f'Payer: {payer_temp}')

    return(amount,awo,ano,bank,bank_address,ifsc,ch_details,date,payee,payer_temp)



def cts_results(request):
    cheque_pic = ImageUpload.objects.latest('id')
    img_url = cheque_pic.cheque_image.url
    amount,awo,ano,bank,bank_address,ifsc,ch_details,date,payee,payer_temp = img_read(img_url)
    #return(render(request, 'cts-results.html', {'cheque_pic':img_url}))
    return(render(request, 'cts-results.html', {'cheque_pic':img_url,'amount':amount,'awo':awo,'ano':ano,'bank':bank,'bank_address':bank_address,'ifsc':ifsc,'ch_details':ch_details,'date':date,'payee':payee,'payer_temp':payer_temp}))
